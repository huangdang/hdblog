# 一：DOM简介

文档对象模型（Document Object Model，简称 DOM），是 W3C 组织推荐的处理可扩展标记语言（HTML或者XML）的标准编程接口。 W3C 已经定义了一系列的 DOM 接口，通过这些 DOM 接口可以改变网页的内容、结构和样式。

1. 文档：一个页面就是一个文档，DOM 中使用 document 表示
2. 元素：页面中的所有标签都是元素，DOM 中使用 element 表示
3. 节点：网页中的所有内容都是节点（标签、属性、文本、注释等），DOM 中使用 node 表示

# 二：获取元素

### 1：通过ID获取：

```javascript
document.getElementById('id');
```

### 2：通过标签名获取：

```javascript
document.getElementsByTagName('标签名');
```

### 3：通过类名获取：

```javascript
document.getElementsByClassName('类名');
```

### 4：通过单选择器获取：

```javascript
document.querySelector('.选择器');   //如果是类名必须加‘.’   id必须加‘#’   标签直接写标签名‘div’
```

### 5：通过多选择器获取：

```javascript
document.querySelectorAll('选择器');
```

### 6：获取body元素：

```javascript
doucumnet.body // 返回body元素对象
```

### 7：获取html元素：

```javascript
document.documentElement
```

# 三：事件对象

## 事件三要素

1. 事件源 （谁）（比如说’div’）
2. 事件类型 （什么事件）(比如说’click’)
3. 事件处理程序 （做啥）（函数function（）{}）

## 事件执行步骤

1. 获取事件源 （上面获取元素）
2. 注册事件（绑定事件）
3. 添加事件处理程序（采取函数赋值形式）

## 常见的鼠标事件


| 事件名称    | 触发条件         |
| ----------- | ---------------- |
| onclick     | 鼠标点击左键触发 |
| onmouseover | 鼠标经过触发     |
| onmouseoup  | 鼠标离开触发     |
| onfocus     | 获取焦点触发     |
| onblur      | 失去焦点触发     |
| onmousemove | 鼠标移动触发     |
| onmousedown | 鼠标按下触发     |
| onmouseup   | 鼠标松开触发     |

# 四：操作元素

## 1：改变元素内容

```javascript
document.write('');  //页面文档流加载完毕会导致页面重绘
element.innerText  // 拼接字符串的话会缓冲慢   数组块执行块
element.innerHTML  //创建新元素   结构清晰
```

## 2：样式属性操作

我们可以通过 JS 修改元素的大小、颜色、位置等样式。

```javascript
element.style  //行内样式属性
element.className  //类名样式属性
```

注意：

1. 如果样式修改较多，可以采取操作类名方式更改元素样式。
2. class因为是个保留字，因此使用className来操作元素类名属性
3. className 会直接更改元素的类名，会覆盖原先的类名。

## 3：操作常见元素属性

src、href、title、alt等（就是可以给这些元素添加属性内容或者改变属性内容）

## 4：操作表单元素属性

type、value、checked、selected、disabled（常见）

## 5：自定义属性

### 获取属性值：

```javascript
1: element.属性  // 设置内置属性值。 传统方式  通过输出  但不能输出自定义属性
 例如：console.log(div.id);
2: element.getAttribute('属性')   //主要获得自定义的属性 （标准） 我们程序员自定义的属性
例如：console.log(div.getAttribute('nihao'));
```

### 设置属性值：

```
1:element.属性 = '值'; 例如: div.id = 'lgh'; 
2: element.setAttribute('属性', 内容)   例如:  div.setAttribute('nihao', 123)
```

### 移除属性值：

```
element.removeAttribute('属性'); 
例如：div.removeAttribute('nihao')
```

# 五：节点操作

## 1：节点概述

获取元素通常有两种方式 利用节点使操作更简单 但有兼容性网页中的所有内容都是节点（标签、属性、文本、注释等），在DOM 中，节点使用 node 来表示。
HTML DOM 树中的所有节点均可通过 JavaScript 进行访问，所有 HTML 元素（节点）均可被修改，也可以创建或删除。

​	1.元素节点 nodeType 为 1
​	2.属性节点 nodeType 为 2
​	3.文本节点 nodeType 为 3

## 2：节点层级

### 获取父节点

```javascript
parentNode 获取父节点  亲爸爸
例如:console.log(box1.parentNode);
```

### 获取子节点

```
1:获取子节点  childNodes 所有节点 包含文本节点等 
2: 一般用children 只有子节点  不包含文本节点等等
例如:console.log(ul.children);
3:获取第一个/最后一个子节点 firstChild / lastchild  返回第一个子节点（保含文本节点等等）
4: firstElementChild / lastElementChild 有兼容性
5: 元素.children[i]  //用children写 最常用
```

### 获取兄弟节点

```
//兄弟节点  （包含元素文本节点）
1：下一个兄弟节点 nextSibling   上一个兄弟节点 previousSibling
2: nextElementSibing   previousElementSibling  兄弟元素节点  （不包含文本节点等等）
```

## 创建节点

```
document.createElement('tagName') 
例如: var li = document.createElement('li');
```

## 添加节点

```
插入  node.appendChild (child)  node:父级 child 子级 后面追加  //node.appendChild() 方法将一个节点添加到指定父节点的子节点列表末尾。类似于 CSS 里面的after 伪元素。
例如: ul.appendChild(li)
插入 node.insertBefore(child,指定元素) //node.insertBefore() 方法将一个节点添加到父节点的指定子节点前面。类似于 CSS 里面的 before 
伪元素。
例如: ul.insertBefore(lili, ul.children[0])
```

## 删除节点

```
node.removeChild(child) *//方法从 DOM 中删除一个子节点，返回删除的节点*
```

