// 声明变量3种方法
// var 没有块级作用域
// let 和 const 有块级作用域

{
	// var 重复声明相同变量不会报错
	// var c = 456
	// console.log(c);//456
	// var c = 1233
	// console.log(c);//1233
	
	// // let 不能重复声明变量
	// let b = 78789
	// let a = 123 //这条语句会报错
	// b = 12
	
	// const 一旦声明并赋值就不能再修改 一般用来定义常亮
	const d = 123 // 
	// d = 456
	
}
// console.log(b);// b is not defined
// console.log(c);

// 变量命名规则
var b = 123

// % 余数

var a = 1;
var b = 2;
a+=b //a = a+b

var i = 0;
// i++; // i = 0
// ++i// 1
console.log(i)// 1
